import { ADD, DELETE,UPDATE } from "./action";
const initialState = JSON.parse(localStorage.getItem("students")) || [];

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case ADD:
            return [...state, action.payload];
        case DELETE:
            return state.filter(s => s.id !== action.payload)
        case UPDATE:
            return state.map(s=>
                s.id === action.payload.id ? action.payload : s
            )    
        default:
            return state;
    }
}

export default reducer;