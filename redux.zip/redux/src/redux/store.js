import reducer from "./reducer";
import {createStore} from 'redux'

const store = createStore(reducer)

store.subscribe(()=>{
    localStorage.setItem("students", JSON.stringify(store.getState()))
})

export default store;