export const ADD = "ADD";
export const DELETE = "DELETE";
export const UPDATE = "UPDATE";

export const addStudent = (student) => ({
    type:ADD,
    payload:student
})

export const deleteStudent = (id) => ({
    type:DELETE,
    payload: id
})

export const editStudents = (student) => ({
    type:UPDATE,
    payload:student
})