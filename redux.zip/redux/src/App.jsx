// import { createStore } from "redux";
// import { Provider, useSelector, useDispatch } from "react-redux";

import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addStudent, deleteStudent, editStudents } from "./redux/action";

// const reducer = (state = { count: 0 }, action) => {
//   switch (action.type) {
//     case "INCREMENT":
//       return { count: state.count + 1 };
//     case "DECREMENT":
//       return { count: state.count - 1 };
//     case "RESET":
//       return { count: 0 };
//     default:
//       return state;
//   }
// };

// const store = createStore(reducer);

// function Counter() {
//   const count = useSelector((state) => state.count);
//   const dispatch = useDispatch();

//   return (
//     <div>
//       <h1>Count: {count}</h1>
//       <button onClick={() => dispatch({ type: "INCREMENT" })}>+</button>
//       <button onClick={() => dispatch({ type: "DECREMENT" })}>-</button>
//       <button onClick={() => dispatch({ type: "RESET" })}>Reset</button>
//     </div>
//   );
// }

export default function App() {
  const students = useSelector(state => state);
  const dispatch = useDispatch();

  const [form, setForm] = useState({
    name:"",
    email:""
  })
  const [editId, setEditId] = useState(null);
  const handleSubmit = (e) => {
    e.preventDefault()
    if(editId){
      dispatch(editStudents({ id: editId, ...form}))
    }else{
      dispatch(addStudent({ id: editId, ...form}))
    }

    setForm({ name:"" , email:"" });
  }

  const handleEdit = (student) => {
    setForm({ name: student.name, email:student.email});
    setEditId(student.id);
  }
  return (
    <>
    <h2>Student CRUD</h2>
    <form onSubmit={handleSubmit}>
      <input type="text" value={form.name} onChange={e => setForm({...form, name: e.target.value})}/>
      <input type="text" value={form.email} onChange={e => setForm({...form, email:e.target.email})}/>
      <button type="submit">{editId ? "Update" : "Add"}</button>
    </form>

    <h3>Student List</h3>
    {students.map(student => (
      <div key={student.id}>
        <p>{student.name} - {student.email}</p>
        <button onClick={()=>handleEdit(student)}> 
          edit 
        </button>
        <button onClick={()=>dispatch(deleteStudent(student.id))}>
          delete
        </button>
      </div>
    ))}
    </>
  );
}