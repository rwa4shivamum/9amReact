const BASEURL = "http://localhost:3000/api"

export const createUser = async(payload1) => {
    try {
        console.log(payload1)
        const res = await fetch(`${BASEURL}/users`,{
            method:"POST",
            body:JSON.stringify(payload1),
            headers:{
                "content-type":"application/json"
            }            
        })
        const result = await res.json()
        return result
    } catch (error) {
        console.log(`Error in Create User ${error.message}`)        
    }
}

createUser({
  "name": "Alex",
  "email": "alex@gmail.com",
  "age": 24
}).then((res)=> console.log(res)).catch((error)=>console.log(error))

export const getuser = async() => {
    try {
        const res = await fetch(`${BASEURL}/users`,{
            method:"GET"
        })
        const result = await res.json();
        return result
    } catch (error) {
        console.log(error.message)
    }
}

getuser().then((res)=> console.log(res)).catch((error)=> console.log(error))

export const updateUser = async(payload,id)=>{
    try {
        const res = await fetch(`${BASEURL}/users/${id}`,{
            method:"PUT",
            body:JSON.stringify(payload),
            headers:{
                "content-type":"application/json"
            }
        })
        const result = await res.json()
        return result
    } catch (error) {
        console.log(error)
    }
}

updateUser({},1).then((res)=> console.log(res)).catch((error)=> console.log(error))

export const deleteUser = async(id)=>{
    try {
        const res = await fetch(`${BASEURL}/users/${id}`,{
            method:"DELETE",
        })
        const result = await res.json()
        return result
    } catch (error) {
        console.log(error)
    }
}