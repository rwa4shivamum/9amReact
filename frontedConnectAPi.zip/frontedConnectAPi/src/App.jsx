import { useState, useEffect } from 'react'
import './App.css'
import { createUser } from './api'

function App() {
  const [obj, setObj] = useState({
    "name":"",
    "email":"",
    "age":""
  })
  const [data, setData] = useState(null)
  const useEffect = (() => {
    getuser().then((res)=> setData(res)).catch((error)=> console.log(error))
  },[])
  const handleSubmit = async(e) => {
    e.preventDefault()
    await createUser(obj)
  }
  console.log(data)
  return (
   <>
   <form onSubmit={handleSubmit}>
    <input type="text" name='name' value={obj.name} onChange={e => setObj({...obj, name: e.target.value})}/>
    <input type="text" name='email' value={obj.email} onChange={e => setObj({...obj, email: e.target.value})}/>
      <input type="text" value={obj.age} onChange={e => setObj({...obj, age: e.target.value})}/>
      <button type='Submit'>Submit</button>
   </form>
   </>
  )
}

export default App
