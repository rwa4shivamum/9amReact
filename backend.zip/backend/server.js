
const express = require("express");
const cors = require('cors')
const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use(cors())
// In-memory data (No Database)
let users = [
    {
        id: 1,
        name: "John",
        email: "john@gmail.com",
        age: 25
    },
    {
        id: 2,
        name: "David",
        email: "david@gmail.com",
        age: 28
    }
];

// Generate unique IDs
let nextId = 3;

// 1. HOME API
app.get("/", (req, res) => {
    res.send("Node.js CRUD API Server is Running!");
});

// 2. CREATE USER (POST)
app.post("/api/users", (req, res) => {
    const { name, email, age } = req.body;

    if (!name || !email || age === undefined) {
        return res.status(400).json({
            success: false,
            message: "Name, email and age are required"
        });
    }

    const newUser = {
        id: nextId++,
        name,
        email,
        age
    };

    users.push(newUser);

    res.status(201).json({
        success: true,
        message: "User created successfully",
        data: newUser
    });
});

// 3. GET ALL USERS (GET)
app.get("/api/users", (req, res) => {
    res.status(200).json({
        success: true,
        count: users.length,
        data: users
    });
});

// 4. GET SINGLE USER BY ID (GET)
app.get("/api/users/:id", (req, res) => {
    const id = Number(req.params.id);

    const user = users.find(u => u.id === id);

    if (!user) {
        return res.status(404).json({
            success: false,
            message: "User not found"
        });
    }

    res.status(200).json({
        success: true,
        data: user
    });
});

// 5. UPDATE USER (PUT)
app.put("/api/users/:id", (req, res) => {
    const id = Number(req.params.id);

    const userIndex = users.findIndex(u => u.id === id);

    if (userIndex === -1) {
        return res.status(404).json({
            success: false,
            message: "User not found"
        });
    }

    const { name, email, age } = req.body;

    users[userIndex] = {
        ...users[userIndex],
        ...(name !== undefined && { name }),
        ...(email !== undefined && { email }),
        ...(age !== undefined && { age })
    };

    res.status(200).json({
        success: true,
        message: "User updated successfully",
        data: users[userIndex]
    });
});

// 6. DELETE USER (DELETE)
app.delete("/api/users/:id", (req, res) => {
    const id = Number(req.params.id);

    const userIndex = users.findIndex(u => u.id === id);

    if (userIndex === -1) {
        return res.status(404).json({
            success: false,
            message: "User not found"
        });
    }

    const deletedUser = users.splice(userIndex, 1);

    res.status(200).json({
        success: true,
        message: "User deleted successfully",
        data: deletedUser[0]
    });
});

// 7. 404 ROUTE
app.use((req, res) => {
    res.status(404).json({
        success: false,
        message: "API route not found"
    });
});

// START SERVER
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
